Clutt4.5 (THE COLOR UPDATE)
----------------------------------------
Author: CYBER SOLDIER(Clutter)
My youtube channel: https://www.youtube.com/c/ClutterTech/featured
File type: exe
Malware type: Trojan.Win32
OS support: win7/win8/win8.1/win10/win11 (don't run it on an older OS)
Programming language: C#
Version: 4.5 (bonus version)
Old versions: Clutter Destructive, Clutt, Clutt3, Clutt4
----------------------------------------
Very dangerous Trojan horse!!!
Do not run on a real machine!!! 
CONTAINS DANGEROUS CODE!!!
----------------------------------------


